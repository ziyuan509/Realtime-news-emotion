// sketch.js

// --- Global variables ---
let newsFetcher;
let sentimentAnalyzer;
let currentArticle;
let sentimentScore = 0.5;
let isAnalyzing = false;

// --- Cellular Automata variables ---
let grid;
let cellSize = 8;
let cols, rows;

// 🎨 5-Level Color Palette
const colors = {
  veryPositive: { r: 255, g: 223, b: 0 },   // Solar Flare Yellow
  positive: { r: 0, g: 255, b: 127 },       // Spring Green
  neutral: { r: 100, g: 149, b: 237 },      // Cornflower Blue
  negative: { r: 220, g: 20, b: 60 },        // Crimson Red
  veryNegative: { r: 75, g: 0, b: 130 }     // Deep Indigo
};

let visParams = {};

// --- Responsive canvas size calculation function ---
function getResponsiveCanvasSize() {
  const container = document.getElementById('canvas-container');
  const maxWidth = Math.min(window.innerWidth - 40, 800); // Max width 800px, leave 40px margin
  const maxHeight = Math.min(window.innerHeight * 0.6, 500); // Max height 60% of screen or 500px
  
  // Mobile device adaptation
  if (window.innerWidth <= 768) {
    return {
      width: Math.min(window.innerWidth - 20, 350),
      height: Math.min(window.innerHeight * 0.4, 250)
    };
  }
  
  // Tablet device adaptation
  if (window.innerWidth <= 1024) {
    return {
      width: Math.min(window.innerWidth - 30, 600),
      height: Math.min(window.innerHeight * 0.5, 400)
    };
  }
  
  // PC device
  return {
    width: maxWidth,
    height: maxHeight
  };
}

// --- Dynamic cell size adjustment ---
function getResponsiveCellSize(canvasWidth) {
  if (canvasWidth <= 350) return 6;  // Mobile devices use smaller cells
  if (canvasWidth <= 600) return 7;  // Tablet devices
  return 8;  // PC devices
}

// --- p5.js setup function ---
function setup() {
  const canvasSize = getResponsiveCanvasSize();
  const canvas = createCanvas(canvasSize.width, canvasSize.height);
  canvas.parent('canvas-container');
  
  cellSize = getResponsiveCellSize(canvasSize.width);
  
  const apiKey = 'af9531492df242869bcfd2e268f72c73'; // Your API Key
  newsFetcher = new NewsFetcher(apiKey);
  sentimentAnalyzer = new SentimentAnalyzer();
  select('#next-news-btn').mousePressed(getAndAnalyzeNextNews);
  
  cols = floor(width / cellSize);
  rows = floor(height / cellSize);
  
  updateVisualizationParameters(sentimentScore); // Set initial neutral state
  resetAutomata();
  
  // Wait for the AI model to be ready, then load the first news article
  waitForModelAndLoadNews();
}

// --- Window resize handler to readjust canvas ---
function windowResized() {
  const canvasSize = getResponsiveCanvasSize();
  resizeCanvas(canvasSize.width, canvasSize.height);
  
  cellSize = getResponsiveCellSize(canvasSize.width);
  cols = floor(width / cellSize);
  rows = floor(height / cellSize);
  
  resetAutomata(); // Reinitialize grid
}

// --- p5.js draw loop ---
function draw() {
  if (frameCount % visParams.updateSpeed === 0) {
    generateNextGeneration();
  }
  renderAutomata();
}

// Fetches and analyzes news, then updates the visualization level
async function getAndAnalyzeNextNews() {
  if (isAnalyzing) return;
  isAnalyzing = true;
  try {
    if (newsFetcher.articles.length === 0) {
      select('#sentiment-result').html('Fetching News...');
      const success = await newsFetcher.fetchTopHeadlines();
      if (!success) return;
    }
    currentArticle = newsFetcher.getNextArticle();
    if (!currentArticle) return;

    select('#news-title').html(currentArticle.title);
    select('#news-summary').html(currentArticle.description || "No summary");
    select('#sentiment-result').html('Analyzing with AI...');
    if (currentArticle.url) {
        select('#news-url').attribute('href', currentArticle.url);
        select('#news-link').style('display', 'block');
    } else {
        select('#news-link').style('display', 'none');
    }

    const textToAnalyze = currentArticle.content || `${currentArticle.title}. ${currentArticle.description || ''}`;
    const result = await sentimentAnalyzer.predict(textToAnalyze);
    sentimentScore = result.score || 0.5;
    
    updateVisualizationParameters(sentimentScore);
    updateSentimentDisplay(sentimentScore, result);
    resetAutomata();
  } catch (error) {
    console.error('Error during news analysis:', error);
  } finally {
    isAnalyzing = false;
  }
}

// Defines the visual "mood" for each sentiment level
function updateVisualizationParameters(score) {
  if (score >= 0.8) { // Level 5: Very Positive
    visParams = { level: 'Very Positive', color: colors.veryPositive, updateSpeed: 3, mutationRate: 0.005, density: 0.4, bgAlpha: 20, glow: 30 };
  } else if (score >= 0.6) { // Level 4: Positive
    visParams = { level: 'Positive', color: colors.positive, updateSpeed: 5, mutationRate: 0.002, density: 0.3, bgAlpha: 35, glow: 15 };
  } else if (score >= 0.4) { // Level 3: Neutral
    visParams = { level: 'Neutral', color: colors.neutral, updateSpeed: 8, mutationRate: 0.001, density: 0.25, bgAlpha: 40, glow: 0 };
  } else if (score >= 0.2) { // Level 2: Negative
    visParams = { level: 'Negative', color: colors.negative, updateSpeed: 12, mutationRate: 0.0005, density: 0.2, bgAlpha: 50, glow: 0 };
  } else { // Level 1: Very Negative
    visParams = { level: 'Very Negative', color: colors.veryNegative, updateSpeed: 20, mutationRate: 0, density: 0.15, bgAlpha: 60, glow: 0 };
  }
}

// --- Cellular Automata Functions ---
function generateNextGeneration() {
  let next = make2DArray(cols, rows);
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      let neighbors = countNeighbors(grid, i, j);
      let state = grid[i][j];
      if (state == 0 && (neighbors == 3 || neighbors == 6)) {
        next[i][j] = 1;
      } else if (state == 1 && (neighbors == 2 || neighbors == 3)) {
        next[i][j] = 1;
      } else {
        next[i][j] = 0;
      }
      if (next[i][j] == 0 && random(1) < visParams.mutationRate) {
        next[i][j] = 1;
      }
    }
  }
  grid = next;
}

function renderAutomata() {
  noStroke();
  fill(20, 20, 30, visParams.bgAlpha);
  rect(0, 0, width, height);
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      if (grid[i][j] == 1) {
        let x = i * cellSize;
        let y = j * cellSize;
        const c = visParams.color;
        const glow = visParams.glow;
        if (glow > 5) {
          fill(c.r, c.g, c.b, glow);
          rect(x - 1, y - 1, cellSize + 2, cellSize + 2);
        }
        fill(c.r, c.g, c.b, 255);
        rect(x, y, cellSize - 1, cellSize - 1);
      }
    }
  }
}

function resetAutomata() {
  grid = make2DArray(cols, rows);
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      if (random(1) < visParams.density) {
        grid[i][j] = 1;
      }
    }
  }
}

// ✅ --- HELPER FUNCTIONS (Previously Missing) ---

async function waitForModelAndLoadNews() {
  while (!sentimentAnalyzer.isReady()) {
    await new Promise(resolve => setTimeout(resolve, 200));
  }
  await getAndAnalyzeNextNews();
}

function updateSentimentDisplay(score, result = {}) {
  const level = visParams.level || 'Neutral';
  const confidence = result.confidence ? `(Confidence: ${(result.confidence * 100).toFixed(1)}%)` : '';
  const scoreText = `Score: ${score.toFixed(2)}`;
  select('#sentiment-result').html(`${level} | ${scoreText} ${confidence}`);
}

function make2DArray(cols, rows) {
  let arr = new Array(cols);
  for (let i = 0; i < arr.length; i++) {
    arr[i] = new Array(rows).fill(0);
  }
  return arr;
}

function countNeighbors(grid, x, y) {
  let sum = 0;
  for (let i = -1; i < 2; i++) {
    for (let j = -1; j < 2; j++) {
      if (i === 0 && j === 0) continue;
      let col = (x + i + cols) % cols;
      let row = (y + j + rows) % rows;
      sum += grid[col][row];
    }
  }
  return sum;
}