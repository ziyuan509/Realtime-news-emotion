// sentiment.js

class SentimentAnalyzer {
  constructor() {
    this.isModelReady = false;
    this.initializeModel();
    console.log('Advanced AI Sentiment Analyzer initializing...');
  }

  async initializeModel() {
    try {
      while (!window.sentimentPipe) {
        console.log('Waiting for Transformers.js model to load...');
        await new Promise(resolve => setTimeout(resolve, 500));
      }
      this.isModelReady = true;
      console.log('Advanced AI Sentiment Analyzer ready!');
    } catch (error) {
      console.error('Failed to initialize AI sentiment model:', error);
      this.isModelReady = false;
    }
  }

  async predict(text) {
    if (!text || typeof text !== 'string') {
      return { score: 0.5, label: 'NEUTRAL', confidence: 0.5 };
    }

    if (!this.isModelReady || !window.sentimentPipe) {
      console.warn('AI model not ready, using fallback analysis');
      return this.fallbackAnalysis(text);
    }

    try {
      const result = await window.sentimentPipe(text);
      
      if (result && result.length > 0) {
        const sentiment = result[0];
        let score;
        
        // A more nuanced scoring logic to avoid extreme values.
        // We use a power function to make the score less sensitive at high confidence.
        const confidence = Math.pow(sentiment.score, 1.5);
        
        if (sentiment.label === 'POSITIVE') {
          // Map to 0.5-1.0, but moderated
          score = 0.5 + (confidence * 0.4); // Max score will be 0.9, not 1.0
        } else if (sentiment.label === 'NEGATIVE') {
          // Map to 0.0-0.5, but moderated
          score = 0.5 - (confidence * 0.4); // Min score will be 0.1, not 0.0
        } else {
          score = 0.5; // Neutral
        }
        
        // Ensure score is within [0, 1] boundary, just in case.
        score = Math.max(0, Math.min(1, score));

        console.log(`AI Sentiment Analysis Result:`);
        return { score: score, label: sentiment.label, confidence: sentiment.score };
      }
      return this.fallbackAnalysis(text);
    } catch (error) {
      console.error('Error during AI sentiment analysis:', error);
      return this.fallbackAnalysis(text);
    }
  }

  fallbackAnalysis(text) {
    console.log('Using fallback keyword-based sentiment analysis');
    const positiveWords = ['good', 'great', 'excellent', 'amazing', 'wonderful', 'fantastic', 'awesome', 'positive', 'success', 'win', 'victory', 'achievement', 'progress', 'growth', 'happy', 'joy', 'love', 'like', 'best', 'better', 'hope', 'optimistic'];
    const negativeWords = ['bad', 'terrible', 'awful', 'horrible', 'worst', 'worse', 'negative', 'poor', 'fail', 'failure', 'loss', 'crisis', 'disaster', 'sad', 'angry', 'fear', 'violence', 'war', 'conflict', 'attack', 'death', 'crime', 'hate'];
    const lowerText = text.toLowerCase();
    let positiveScore = 0;
    let negativeScore = 0;
    positiveWords.forEach(word => { const regex = new RegExp('\\b' + word + '\\b', 'gi'); const matches = lowerText.match(regex); if (matches) positiveScore += matches.length; });
    negativeWords.forEach(word => { const regex = new RegExp('\\b' + word + '\\b', 'gi'); const matches = lowerText.match(regex); if (matches) negativeScore += matches.length; });
    const totalWords = positiveScore + negativeScore;
    let score = totalWords === 0 ? 0.5 : positiveScore / totalWords;
    return { score: score, label: 'FALLBACK', confidence: 0.7 };
  }

  isReady() {
    return this.isModelReady && !!window.sentimentPipe;
  }
}