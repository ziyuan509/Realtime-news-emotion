// sketch.js

// Global variables
let newsFetcher;
let sentimentAnalyzer;
let currentArticle;
let sentimentScore = 0.5; // Initial sentiment score is neutral

// --- 2D Cellular Automata (Game of Life) variables ---
let grid;
let cellSize = 10;
let cols, rows;

// New, refined color scheme
const colors = {
  positive: { r: 0, g: 255, b: 127 },    // Vibrant Spring Green
  negative: { r: 220, g: 20, b: 60 },     // Crimson Red
  neutral: { r: 100, g: 149, b: 237 }   // Calm Cornflower Blue
};

// p5.js setup function, runs once at the start
function setup() {
  const canvas = createCanvas(600, 400);
  canvas.parent('canvas-container');

  // 1. Initialize the news fetcher and sentiment analyzer
  const apiKey = 'af9531492df242869bcfd2e268f72c73'; // Your API Key
  newsFetcher = new NewsFetcher(apiKey);
  sentimentAnalyzer = new SentimentAnalyzer();

  // 2. Bind the button event
  select('#next-news-btn').mousePressed(getAndAnalyzeNextNews);

  // 3. Initial news load
  getAndAnalyzeNextNews();

  // 4. Initialize the 2D Cellular Automata
  cols = floor(width / cellSize);
  rows = floor(height / cellSize);
  resetAutomata();
}

// p5.js draw function, runs in a loop
function draw() {
  // Adjust growth speed based on sentiment score
  // Extreme sentiment (close to 0 or 1) results in faster updates.
  let speed = 1 + floor(abs(sentimentScore - 0.5) * 18);
  
  // Generate the next state of the automata at the calculated speed
  if (frameCount % (10 - speed) === 0) {
    generateNextGeneration();
  }
  
  renderAutomata();
}

// Fetch and analyze the next news article
async function getAndAnalyzeNextNews() {
  if (newsFetcher.articles.length === 0) {
    const success = await newsFetcher.fetchTopHeadlines();
    if (!success) return;
  }

  currentArticle = newsFetcher.getNextArticle();
  if (currentArticle) {
    select('#news-title').html(currentArticle.title);
    select('#news-summary').html(currentArticle.description || "No summary available");
    select('#sentiment-result').html('Analyzing...');
    
    // Display the news link
    if (currentArticle.url) {
      select('#news-url').attribute('href', currentArticle.url);
      select('#news-link').style('display', 'block');
    } else {
      select('#news-link').style('display', 'none');
    }

    // Use full content if available, otherwise use title + description
    try {
      // Use complete content for analysis
      const textToAnalyze = currentArticle.content || 
                           `${currentArticle.title}. ${currentArticle.description || ''}`;
      console.log('Analyzing text:', textToAnalyze);
      
      // Directly call predict method (no need for await, as it's synchronous now)
      const result = sentimentAnalyzer.predict(textToAnalyze);
      console.log('Sentiment analysis result:', result);
      
      // Extract score
      const score = result.score || 0.5;
      
      // Ensure score is a valid number
      sentimentScore = (typeof score === 'number' && !isNaN(score)) ? score : 0.5;
      updateSentimentDisplay(sentimentScore);
    } catch (error) {
      console.error('Error during sentiment analysis:', error);
      sentimentScore = 0.5;
      updateSentimentDisplay(sentimentScore);
    }
    
    resetAutomata(); // Reset the visualization for the new article
  }
}

// Update the text display for the sentiment result
function updateSentimentDisplay(score) {
  let sentimentText;
  if (score > 0.6) {
    sentimentText = `Positive (${score.toFixed(2)})`;
  } else if (score < 0.4) {
    sentimentText = `Negative (${score.toFixed(2)})`;
  } else {
    sentimentText = `Neutral (${score.toFixed(2)})`;
  }
  select('#sentiment-result').html(sentimentText);
}

// --- 2D Cellular Automata Functions ---

// Reset and seed the automata with a random pattern
function resetAutomata() {
  grid = make2DArray(cols, rows);
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      // Create a random starting state for more interesting patterns
      grid[i][j] = floor(random(2));
    }
  }
}

// Generate the next generation based on Game of Life rules
function generateNextGeneration() {
  let nextGrid = make2DArray(cols, rows);

  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      let state = grid[i][j];
      let neighbors = countNeighbors(grid, i, j);

      // Apply Conway's Game of Life rules
      if (state === 0 && neighbors === 3) {
        nextGrid[i][j] = 1; // A new cell is born
      } else if (state === 1 && (neighbors < 2 || neighbors > 3)) {
        nextGrid[i][j] = 0; // Cell dies
      } else {
        nextGrid[i][j] = state; // Cell remains the same
      }
    }
  }
  grid = nextGrid;
}

// Render the entire grid
function renderAutomata() {
  // Set background based on sentiment for a more immersive effect
  if (sentimentScore < 0.4) {
    background(34, 34, 34); // Dark background for negative news
  } else {
    background(240); // Light background for neutral/positive
  }
  
  // Select cell color based on sentiment
  let c;
  if (sentimentScore > 0.6) {
    c = colors.positive;
  } else if (sentimentScore < 0.4) {
    c = colors.negative;
  } else {
    c = colors.neutral;
  }

  noStroke();

  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      if (grid[i][j] === 1) {
        // Add slight random variation to the color for a richer texture
        fill(
          c.r + random(-25, 25),
          c.g + random(-25, 25),
          c.b + random(-25, 25)
        );
        let x = i * cellSize;
        let y = j * cellSize;
        rect(x, y, cellSize, cellSize);
      }
    }
  }
}

// Helper function to create a 2D array
function make2DArray(cols, rows) {
  let arr = new Array(cols);
  for (let i = 0; i < arr.length; i++) {
    arr[i] = new Array(rows);
  }
  return arr;
}

// Helper function to count live neighbors for a cell
function countNeighbors(grid, x, y) {
  let sum = 0;
  for (let i = -1; i < 2; i++) {
    for (let j = -1; j < 2; j++) {
      // Wrap around edges to create a continuous space
      let col = (x + i + cols) % cols;
      let row = (y + j + rows) % rows;
      sum += grid[col][row];
    }
  }
  sum -= grid[x][y]; // Don't count the cell itself
  return sum;
}