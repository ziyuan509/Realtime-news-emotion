

class SentimentAnalyzer {
  constructor() {
    this.isModelReady = true; 
    this.positiveWords = [
      'good', 'great', 'excellent', 'amazing', 'wonderful', 'fantastic', 'awesome',
      'positive', 'success', 'win', 'victory', 'achievement', 'progress', 'growth',
      'improvement', 'benefit', 'advantage', 'opportunity', 'breakthrough', 'innovation',
      'happy', 'joy', 'celebration', 'love', 'like', 'enjoy', 'pleased', 'satisfied',
      'recovery', 'boost', 'rise', 'increase', 'gain', 'profit', 'up', 'high',
      'strong', 'powerful', 'effective', 'efficient', 'successful', 'winning',
      'best', 'better', 'top', 'leading', 'first', 'champion', 'hero', 'star',
      'beautiful', 'brilliant', 'smart', 'clever', 'wise', 'perfect', 'ideal',
      'hope', 'optimistic', 'confident', 'proud', 'excited', 'thrilled', 'delighted'
    ];
    
    this.negativeWords = [
      'bad', 'terrible', 'awful', 'horrible', 'worst', 'worse', 'negative', 'poor',
      'fail', 'failure', 'loss', 'lose', 'defeat', 'problem', 'issue', 'trouble',
      'crisis', 'disaster', 'tragedy', 'accident', 'crash', 'collapse', 'decline',
      'decrease', 'fall', 'drop', 'down', 'low', 'weak', 'broken', 'damaged',
      'sad', 'angry', 'mad', 'upset', 'disappointed', 'frustrated', 'worried',
      'fear', 'scared', 'afraid', 'concern', 'threat', 'danger', 'risk', 'warning',
      'violence', 'war', 'conflict', 'fight', 'attack', 'kill', 'death', 'dead',
      'injury', 'hurt', 'pain', 'suffer', 'victim', 'crime', 'illegal', 'wrong',
      'hate', 'dislike', 'reject', 'refuse', 'deny', 'oppose', 'against', 'anti',
      'corrupt', 'scandal', 'fraud', 'lie', 'fake', 'false', 'mistake', 'error'
    ];
    
    this.neutralWords = [
      'report', 'news', 'update', 'information', 'data', 'study', 'research',
      'analysis', 'meeting', 'conference', 'discussion', 'plan', 'project',
      'system', 'process', 'method', 'approach', 'strategy', 'policy'
    ];
    
    
    this.intensifiers = [
      'very', 'extremely', 'incredibly', 'absolutely', 'completely', 'totally',
      'utterly', 'highly', 'especially', 'particularly', 'remarkably', 'truly'
    ];
    
    this.negators = [
      'not', 'no', 'never', 'neither', 'nor', 'none', 'nothing', 'nowhere', 
      'hardly', 'scarcely', 'barely', 'rarely'
    ];
    
    console.log('Enhanced keyword-based sentiment analyzer initialized successfully!');
  }

  // Enhanced sentiment analysis method using only keywords
  predict(text) {
    if (!text || typeof text !== 'string') {
      return { score: 0.5 };
    }
    
    const lowerText = text.toLowerCase();
    let positiveScore = 0;
    let negativeScore = 0;
    let neutralScore = 0;
    let intensifierCount = 0;
    let negationCount = 0;
    
    // Calculate positive word score
    this.positiveWords.forEach(word => {
      const regex = new RegExp('\\b' + word + '\\b', 'gi');
      const matches = lowerText.match(regex);
      if (matches) {
        positiveScore += matches.length;
      }
    });
    
    // Calculate negative word score
    this.negativeWords.forEach(word => {
      const regex = new RegExp('\\b' + word + '\\b', 'gi');
      const matches = lowerText.match(regex);
      if (matches) {
        negativeScore += matches.length;
      }
    });
    
    // Calculate neutral word score
    this.neutralWords.forEach(word => {
      const regex = new RegExp('\\b' + word + '\\b', 'gi');
      const matches = lowerText.match(regex);
      if (matches) {
        neutralScore += matches.length;
      }
    });
    
    // Count intensifiers
    this.intensifiers.forEach(word => {
      const regex = new RegExp('\\b' + word + '\\b', 'gi');
      const matches = lowerText.match(regex);
      if (matches) {
        intensifierCount += matches.length;
      }
    });
    
    // Count negations
    this.negators.forEach(word => {
      const regex = new RegExp('\\b' + word + '\\b', 'gi');
      const matches = lowerText.match(regex);
      if (matches) {
        negationCount += matches.length;
      }
    });
    
    // Special case handling
    const totalSentimentWords = positiveScore + negativeScore;
    let finalScore;
    
    if (totalSentimentWords === 0) {
      // If no sentiment words found, check text length and neutral words
      if (neutralScore > 0) {
        finalScore = 0.5; // Neutral
      } else {
        // Simple heuristic based on text length
        const wordCount = lowerText.split(/\s+/).length;
        if (wordCount < 5) {
          finalScore = 0.5; // Short text defaults to neutral
        } else {
          finalScore = 0.45; // Long text without obvious sentiment words, slightly negative
        }
      }
    } else {
      // Calculate sentiment score (0-1 range)
      let rawScore = positiveScore / totalSentimentWords;
      
      // Apply negation adjustment - if odd number of negations, flip the sentiment
      if (negationCount % 2 === 1) {
        rawScore = 1 - rawScore;
      }
      
      // Apply intensifier adjustment
      const intensifierFactor = 1 + (intensifierCount * 0.05);
      if (rawScore > 0.5) {
        rawScore = Math.min(0.9, 0.5 + ((rawScore - 0.5) * intensifierFactor));
      } else if (rawScore < 0.5) {
        rawScore = Math.max(0.1, 0.5 - ((0.5 - rawScore) * intensifierFactor));
      }
      
      // Apply weight adjustment
      if (positiveScore > negativeScore * 2) {
        finalScore = Math.min(0.85, rawScore + 0.1); // Strong positive
      } else if (negativeScore > positiveScore * 2) {
        finalScore = Math.max(0.15, rawScore - 0.1); // Strong negative
      } else {
        finalScore = rawScore;
      }
    }
    
    // Ensure score is within reasonable range
    finalScore = Math.max(0.1, Math.min(0.9, finalScore));
    
    console.log(`Sentiment Analysis - Text: "${text.substring(0, 100)}..."`);
    console.log(`Positive words: ${positiveScore}, Negative words: ${negativeScore}, Final score: ${finalScore.toFixed(3)}`);
    
    return { score: finalScore };
  }

  // Check if model is ready
  isReady() {
    return this.isModelReady;
  }
}